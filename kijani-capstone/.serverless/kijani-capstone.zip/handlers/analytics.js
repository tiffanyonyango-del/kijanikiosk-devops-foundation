'use strict';

const {
  S3Client,
  GetObjectCommand
} = require('@aws-sdk/client-s3');

const s3 = new S3Client({
  region: 'af-south-1',
  endpoint: 'http://localhost:4569',
  forcePathStyle: true,
  credentials: {
    accessKeyId: 'S3RVER',
    secretAccessKey: 'S3RVER'
  }
});

const streamToString = async (stream) => {
  const chunks = [];

  for await (const chunk of stream) {
    chunks.push(Buffer.from(chunk));
  }

  return Buffer.concat(chunks).toString('utf-8');
};

module.exports.analyzeReceipts = async (event) => {
  for (const record of event.Records || []) {
    const sourceBucket = record.s3?.bucket?.name;

    const sourceKey = decodeURIComponent(
      (record.s3?.object?.key || '').replace(/\+/g, ' ')
    );

    if (!sourceBucket || !sourceKey) {
      console.warn(JSON.stringify({
        event: 'receipt.analytics.invalid',
        message: 'S3 event did not contain a valid bucket or object key'
      }));

      continue;
    }

    const object = await s3.send(
      new GetObjectCommand({
        Bucket: sourceBucket,
        Key: sourceKey
      })
    );

    const receipt = JSON.parse(
      await streamToString(object.Body)
    );

    const analytics = {
      orderId: receipt.orderId,
      receiptId: receipt.receiptId,
      amount: Number(receipt.amount || 0),
      currency: receipt.currency || 'KES',
      analyzedAt: new Date().toISOString()
    };

    console.log(JSON.stringify({
      event: 'receipt.analyzed',
      ...analytics,
      sourceBucket,
      sourceKey
    }));
  }

  return {
    statusCode: 200
  };
};